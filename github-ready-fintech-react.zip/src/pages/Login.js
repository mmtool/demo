import { useState } from "react";
import { loginApi } from "../api/mockApi";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      const res = await loginApi(email, password);
      onLogin(res.user);
    } catch (e) {
      alert(e);
    }
  };

  return (
    <div className="container">
      <h2>Login</h2>

      <input placeholder="demo@bank.com" onChange={e => setEmail(e.target.value)} />
      <input type="password" placeholder="1234" onChange={e => setPassword(e.target.value)} />

      <button onClick={handleLogin}>Login</button>

      <small>Demo: demo@bank.com / 1234</small>
    </div>
  );
}
