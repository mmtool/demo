import { useState } from "react";
import { transferMoney } from "../api/mockApi";

export default function Transfer({ goBack }) {
  const [amount, setAmount] = useState("");
  const [result, setResult] = useState(null);

  const send = async () => {
    const res = await transferMoney(amount);
    setResult(res);
  };

  return (
    <div className="container">
      <h2>Transfer Money</h2>

      <input placeholder="Amount" onChange={e => setAmount(e.target.value)} />

      <button onClick={send}>Send</button>

      {result && (
        <p>{result.status} - {result.txId}</p>
      )}

      <button onClick={goBack}>Back</button>
    </div>
  );
}
