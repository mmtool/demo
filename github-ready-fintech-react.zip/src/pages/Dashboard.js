import { useEffect, useState } from "react";
import { getBalance } from "../api/mockApi";

export default function Dashboard({ user, goTransfer, logout }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    getBalance().then(setData);
  }, []);

  return (
    <div className="container">
      <h2>Welcome {user?.name}</h2>

      {data ? (
        <>
          <p>Account: {data.account}</p>
          <h3>Balance: {data.balance} MMK</h3>
        </>
      ) : (
        <p>Loading...</p>
      )}

      <button onClick={goTransfer}>Transfer</button>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
