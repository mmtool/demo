export const loginApi = (email, password) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (email === "demo@bank.com" && password === "1234") {
        resolve({ user: { name: "Kaung", id: 1 } });
      } else {
        reject("Invalid credentials");
      }
    }, 800);
  });
};

export const getBalance = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ account: "MM-00112233", balance: 750000 });
    }, 800);
  });
};

export const transferMoney = (amount) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        status: "SUCCESS",
        txId: "TXN" + Date.now()
      });
    }, 800);
  });
};
