import { useState } from "react";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Transfer from "./pages/Transfer";

export default function App() {
  const [page, setPage] = useState("login");
  const [user, setUser] = useState(null);

  return (
    <div>
      {page === "login" && (
        <Login onLogin={(u) => { setUser(u); setPage("dashboard"); }} />
      )}

      {page === "dashboard" && (
        <Dashboard
          user={user}
          goTransfer={() => setPage("transfer")}
          logout={() => setPage("login")}
        />
      )}

      {page === "transfer" && (
        <Transfer goBack={() => setPage("dashboard")} />
      )}
    </div>
  );
}
